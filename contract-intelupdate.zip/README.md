# Contract Intelligence API (FastAPI)

## Quickstart (local, Docker)
1. Build & run:
   docker-compose up --build

2. Open Swagger:
   http://localhost:8000/docs

3. Ingest PDFs:
   curl -F "files=@/path/to/contract1.pdf" -F "files=@/path/to/contract2.pdf" localhost:8000/ingest

4. Extract:
   curl -X POST -H "Content-Type: application/json" -d '{"document_id":1}' localhost:8000/extract

5. Ask:
   curl -X POST -H "Content-Type: application/json" -d '{"question":"What is the termination notice period?"}' localhost:8000/ask

6. Audit:
   curl -X POST -H "Content-Type: application/json" -d '{"document_id":1}' localhost:8000/audit
